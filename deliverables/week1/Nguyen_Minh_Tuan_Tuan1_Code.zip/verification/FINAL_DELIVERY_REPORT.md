# Bàn giao riêng tuần 1 — 28/11/2026

Phạm vi: PELD, prev(i) trong collate_fn, demo bước 1–4. Trạng thái **PASS kiểm nghiệm thực thi trong môi trường local**, không phải cam kết ASR/diarization chính xác 100%.

## Thay đổi và tối ưu
Tách demo/preprocess_video.py ra khỏi tiền xử lý training và SECNet. Chạy demo không cần DATA, vocabulary, GloVe, PyTorch hoặc Gradio. Các bước 1–4 dùng chung một hiện thực với pipeline đầy đủ, tránh hai bản code lệch nhau. Xuất audio.wav, result.json và transcript.csv. Backend được nạp một lần khi xử lý nhiều video trong cùng tiến trình; --offline dùng cache ASR.

## Kiểm nghiệm
- Gói CODE đã giải nén sang thư mục riêng không có DATA, không có demo/pipeline.py hay src/preprocess.py. Chạy 13 test tuần 1: PASS (`tests_unpacked.log`).
- Toàn repo sau tách: 18 test PASS, 2 cảnh báo deprecation từ thư viện ngoài (`all_tests.log`).
- Chạy lại DataLoader thật: 359 batch, 1.432 dialogue, 13.708 câu. PELD so với bảng gốc và prev_idx so với lịch sử speaker đều PASS (`dataloader_real.log`).
- Chính mã giải nén chạy ASR/diarization thật trên ba video từ âm thanh MELD dev: PASS (`demo_verification.json`, `demo_real.log`). Đầu ra 7/12/12 câu. Kiểm tra mono16k, timestamp, giới hạn câu, giữ nguyên từ khi ghép, JSON/CSV khớp và không nạp module training/SECNet.
- Pipeline đầy đủ vẫn tạo tensor trên video thật sau khi chuyển sang module chung (`full_pipeline_regression.log`). Không có checkpoint nên không chạy cảm xúc.
- pip check: không có dependency hỏng.

## Giới hạn đã ghi rõ
Video mẫu là waveform có âm thanh thật từ MELD dev, không phải cảnh phim gốc. Có lỗi nhận dạng lời và tách người nói; cần nghe kiểm chứng. Chưa đo WER/DER chuẩn. Chưa xác nhận nghe thủ công. Đã dùng venv dự án hiện có trên Windows/Python3.13; chưa cài và kiểm chứng trên máy nhóm trưởng hoặc một môi trường OS khác. Các đường dẫn trong kết quả/log là bằng chứng lịch sử máy chạy, không phải cấu hình bắt buộc cho người nhận.

Không cần checkpoint SECNet để trình diễn và bàn giao phạm vi tuần 1. Huấn luyện và dự đoán cảm xúc không nằm trong gói tuần 1 này.
