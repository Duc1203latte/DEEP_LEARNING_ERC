# Dữ liệu kiểm thử tuần 1

Nguồn DATA/meld_processed-20261127T120434Z-1-001/meld_processed của người dùng. CSV/PT/PKL giữ nguyên. Bảng PELD có nguồn và thứ tự O,C,E,A,N; meta đã cập nhật có backup từ phiên trước.

| Split | Dialogue | Câu | Batch size4 |
|---|---:|---:|---:|
| train | 1038 | 9989 | 260 |
| dev | 114 | 1109 | 29 |
| test | 280 | 2610 | 70 |
| Tổng | 1432 | 13708 | 359 |

Đã kiểm tra PELD/has_personality/prev_idx trên mọi câu thật. Padding prev_idx=-1, mask personality=False. Other không có PELD. Bảng gốc: configs/personality_peld.json.

Nguồn thiếu train dialogue60, không thêm giả để đạt1039. Hai audio thiếu/hỏng giữ rỗng: train/dia125_utt3 và dev/dia110_utt7. Phần tuần1 này không tái tạo toàn bộ audio; lần kiểm chứng trước đã tái tạo13706audio khớp từng giá trị. Lần hiện tại kiểm tra lại359batch và chạy mới ba video dev thật.

Bằng chứng: dataloader_real.log và demo_verification.json. Chạy được không đồng nghĩa ASR/tách người nói đúng100%; nghe thủ công vẫn pending.
